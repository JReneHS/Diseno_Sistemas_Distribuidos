// Laura Daniela Tellez Castilla --> 2020630527
// Grupo - 4CM11

/*
 *  MIT License
 *
 *  Copyright (c) 2019 Michael Pogrebinsky - Distributed Systems & Cloud Computing with Java
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in all
 *  copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 *  SOFTWARE.
 */
import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpContext;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpClient.Version;
import java.time.Duration;
import java.util.concurrent.Executors;

public class QueryServer {
    private static final String TASK_ENDPOINT = "/task";
    private final int port;
    private HttpServer server;
    private static int generatedCURPS;
    private static final String curpServer1 = "http://146.190.49.131:8081"; //curp2
    private static final String curpServer2 = "http://146.190.123.37:8082"; //curp3
    private static final String curpServer3 = "http://147.182.239.59:8083"; //curp4
    
    public static void main(String[] args) {
        int serverPort = 8080;
        int curpsPorSegundo = 100;
        if (args.length == 2) {
            serverPort = Integer.parseInt(args[0]);
            curpsPorSegundo = Integer.parseInt(args[1]);
        } else {
            System.out.println("Por favor, ingresa el puerto y el numero de CURPS por segundo a generar");
            System.exit(-1);
        }
        QueryServer webServer = new QueryServer(serverPort, curpsPorSegundo);
        webServer.startServer();
        System.out.println("Servidor escuchando en el puerto " + serverPort);
        System.out.println("Y enviando " + curpsPorSegundo + " CURPS por segundo");
        while(true) {
            sendCURPS();
        }
    }
    public QueryServer(int port, int curpsPerSecond) {
        this.port = port;
        this.generatedCURPS = curpsPerSecond;
    }

    public void startServer() {
        try {
            this.server = HttpServer.create(new InetSocketAddress(port), 0);
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }
        HttpContext taskContext = server.createContext(TASK_ENDPOINT);
        taskContext.setHandler(this::handleTaskRequest);
        server.setExecutor(Executors.newFixedThreadPool(8));

        server.start();
    }

    private void handleTaskRequest(HttpExchange exchange) throws IOException {

        // ClienteHTTP
        HttpClient client = HttpClient.newBuilder()
                .version(Version.HTTP_1_1)
                .connectTimeout(Duration.ofMillis(5000))
                .build();

        // Solicitud
        HttpRequest request;

        String query = new String( exchange.getRequestBody().readAllBytes() );
        String response = new String();
        
        if (query.equals("TOTAL")) {
            int total = 0;
            // Total en toda la BD
            request = buildRequest("CURPS", curpServer1);
            total += Integer.parseInt(client.sendAsync(request, HttpResponse.BodyHandlers.ofString()).thenApply(HttpResponse::body).join());
            
            request = buildRequest("CURPS", curpServer2);
            total += Integer.parseInt(client.sendAsync(request, HttpResponse.BodyHandlers.ofString()).thenApply(HttpResponse::body).join());
            
            request = buildRequest("CURPS", curpServer3);
            total += Integer.parseInt(client.sendAsync(request, HttpResponse.BodyHandlers.ofString()).thenApply(HttpResponse::body).join());
            
            response = String.valueOf(total);
        } else if (query.equals("TOTALSERVIDORES")) {
            int total1, total2, total3;
            // Total separado
            request = buildRequest("CURPS", curpServer1);
            total1 = Integer.parseInt(client.sendAsync(request, HttpResponse.BodyHandlers.ofString()).thenApply(HttpResponse::body).join());
            
            request = buildRequest("CURPS", curpServer2);
            total2 = Integer.parseInt(client.sendAsync(request, HttpResponse.BodyHandlers.ofString()).thenApply(HttpResponse::body).join());
            
            request = buildRequest("CURPS", curpServer3);
            total3 = Integer.parseInt(client.sendAsync(request, HttpResponse.BodyHandlers.ofString()).thenApply(HttpResponse::body).join());
            
            response = total1 + " " + total2 + " " + total3;
        } else if ( query.equals("MEMORIA") ) {
            int total = 0;

            // Obtener respuesta en bytes
            request = buildRequest("MEMORIA", curpServer1);
            String bytes = client.sendAsync(request, HttpResponse.BodyHandlers.ofString()).thenApply(HttpResponse::body).join();
            total += Integer.parseInt(bytes);
            response += bytes + " ";

            request = buildRequest("MEMORIA", curpServer2);
            bytes = client.sendAsync(request, HttpResponse.BodyHandlers.ofString()).thenApply(HttpResponse::body).join();
            total += Integer.parseInt(bytes);
            response += bytes + " ";

            request = buildRequest("MEMORIA", curpServer3);
            bytes = client.sendAsync(request, HttpResponse.BodyHandlers.ofString()).thenApply(HttpResponse::body).join();
            total += Integer.parseInt(bytes);
            response += bytes + " ";

            response += total;
        } else if (query.equals("HOMBRE")) {
            // Total de hombres
            
            int total = 0;

            request = buildRequest("HOMBRE", curpServer1);
            total += Integer.parseInt(client.sendAsync(request, HttpResponse.BodyHandlers.ofString()).thenApply(HttpResponse::body).join());
            
            request = buildRequest("HOMBRE", curpServer2);
            total += Integer.parseInt(client.sendAsync(request, HttpResponse.BodyHandlers.ofString()).thenApply(HttpResponse::body).join());
            
            request = buildRequest("HOMBRE", curpServer3);
            total += Integer.parseInt(client.sendAsync(request, HttpResponse.BodyHandlers.ofString()).thenApply(HttpResponse::body).join());

            response = String.valueOf(total);
        } else if (query.equals("MUJER")) {
            // Total de mujeres
            int total = 0;

            request = buildRequest("MUJER", curpServer1);
            total += Integer.parseInt(client.sendAsync(request, HttpResponse.BodyHandlers.ofString()).thenApply(HttpResponse::body).join());
            
            request = buildRequest("MUJER", curpServer2);
            total += Integer.parseInt(client.sendAsync(request, HttpResponse.BodyHandlers.ofString()).thenApply(HttpResponse::body).join());
            
            request = buildRequest("MUJER", curpServer3);
            total += Integer.parseInt(client.sendAsync(request, HttpResponse.BodyHandlers.ofString()).thenApply(HttpResponse::body).join());

            response = String.valueOf(total);
        } else if (query.equals("GENERADOS")) {
            response = String.valueOf(generatedCURPS);
        } else {
            // Busqueda de entidades
            String entidad = query;
            int total = 0;

            request = buildRequest(entidad, curpServer1);
            total += Integer.parseInt(client.sendAsync(request, HttpResponse.BodyHandlers.ofString()).thenApply(HttpResponse::body).join());
            
            request = buildRequest(entidad, curpServer2);
            total += Integer.parseInt(client.sendAsync(request, HttpResponse.BodyHandlers.ofString()).thenApply(HttpResponse::body).join());
            
            request = buildRequest(entidad, curpServer3);
            total += Integer.parseInt(client.sendAsync(request, HttpResponse.BodyHandlers.ofString()).thenApply(HttpResponse::body).join());

            response = String.valueOf(total);
        }

        // Respuesta para terminar conexxión
        sendResponse(response.getBytes(), exchange);

    }

    private void sendResponse(byte[] responseBytes, HttpExchange exchange) throws IOException {
        exchange.sendResponseHeaders(200, responseBytes.length);
        OutputStream outputStream = exchange.getResponseBody();
        outputStream.write(responseBytes);
        outputStream.flush();
        outputStream.close();
        exchange.close();
    }

    public static String crearCURPS() {
        String Letra = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String Numero = "0123456789";
        String Sexo = "HM";
        String Entidad[] = { "AS", "BC", "BS", "CC", "CS", "CH", "CL", "CM", "DF", "DG", "GT", "GR", "HG", "JC", "MC",
                "MN", "MS", "NT", "NL", "OC", "PL", "QT", "QR", "SP", "SL", "SR", "TC", "TL", "TS", "VZ", "YN", "ZS" };
        int indice;
        StringBuilder sb = new StringBuilder(18);
        for (int i = 1; i < 5; i++) {
            indice = (int) (Letra.length() * Math.random());
            sb.append(Letra.charAt(indice));
        }//for
        for (int i = 5; i < 11; i++) {
            indice = (int) (Numero.length() * Math.random());
            sb.append(Numero.charAt(indice));
        }//for
        indice = (int) (Sexo.length() * Math.random());
        sb.append(Sexo.charAt(indice));
        sb.append(Entidad[(int) (Math.random() * 32)]);
        for (int i = 14; i < 17; i++) {
            indice = (int) (Letra.length() * Math.random());
            sb.append(Letra.charAt(indice));
        }//for
        for (int i = 17; i < 19; i++) {
            indice = (int) (Numero.length() * Math.random());
            sb.append(Numero.charAt(indice));
        }//for
        return sb.toString();
    }

    public static void sendCURPS() {
        String curp1 = "";
        String curp2 = "";
        String curp3 = "";
        try {
            curp1 = crearCURPS();
            Thread.sleep(1000 / generatedCURPS);
            curp2 = crearCURPS();
            Thread.sleep(1000 / generatedCURPS);
            curp3 = crearCURPS();
            Thread.sleep(1000 / generatedCURPS);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // Cliente HTTP
        HttpClient client = HttpClient.newBuilder()
                .version(Version.HTTP_1_1)
                .build();
        HttpRequest request;
        try {
            request = HttpRequest.newBuilder()
                    .uri(URI.create(curpServer1 + "/curps"))
                    .POST(HttpRequest.BodyPublishers.ofString(curp1))
                    .build();
            client.send(request, HttpResponse.BodyHandlers.ofString());
            request = HttpRequest.newBuilder()
                    .uri(URI.create(curpServer2 + "/curps"))
                    .POST(HttpRequest.BodyPublishers.ofString(curp2))
                    .build();
            client.send(request, HttpResponse.BodyHandlers.ofString());
            request = HttpRequest.newBuilder()
                    .uri(URI.create(curpServer3 + "/curps"))
                    .POST(HttpRequest.BodyPublishers.ofString(curp3))
                    .build();
            client.send(request, HttpResponse.BodyHandlers.ofString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static HttpRequest buildRequest(String message, String server) {
        HttpRequest request = null;
        try {
            request = HttpRequest.newBuilder()
                    .uri(URI.create(server + "/query"))
                    .POST(HttpRequest.BodyPublishers.ofString(message))
                    .build();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return request;
    }

}
