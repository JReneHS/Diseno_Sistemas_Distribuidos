// Laura Daniela Tellez Castilla --> 2020630527
// Grupo - 4CM11

/*
 *  MIT License
 *
 *  Copyright (c) 2019 Michael Pogrebinsky - Distributed Systems & Cloud Computing with Java
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in all
 *  copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 *  SOFTWARE.
 */
import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpContext;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Array;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

public class CURPServer {
    // Arreglo de curps
    private static ArrayList<String> curps = new ArrayList<>();
    private static final String CURPS_ENDPOINT = "/curps";
    private static final String QUERY_ENDPOINT = "/query";
    private final int port;
    // socket TCP
    private HttpServer server;

    public static void main(String[] args) {
        int serverPort = 8080;
        if (args.length == 1) {
            serverPort = Integer.parseInt(args[0]);
        }
        CURPServer webServer = new CURPServer(serverPort);
        webServer.startServer();
        System.out.println("Servidor escuchando en el puerto " + serverPort);
    }
    
    public CURPServer(int port) {
        this.port = port;
    }

    public void startServer() {
        try {
            this.server = HttpServer.create(new InetSocketAddress(port), 0);
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }
        HttpContext contextoCURPS = server.createContext(QUERY_ENDPOINT);
        HttpContext contextoQuery = server.createContext(CURPS_ENDPOINT);
        contextoCURPS.setHandler(this::handleQueryRequest);
        contextoQuery.setHandler(this::handleCURPRequest);
        
        server.setExecutor(Executors.newFixedThreadPool(8));
        server.start();
    }

    private void handleCURPRequest(HttpExchange exchange) throws IOException {
        String dato = new String(exchange.getRequestBody().readAllBytes());
        curps.add(dato);

        if ( curps.size() % 50 == 0) {
            System.out.println("Recibidos 50 curps");
        }


        sendResponse("OK".getBytes(), exchange);
    }

    private List<String> filterGenero(String genero) {
        //M - MASCULINO
        //F - FEMENINO
        ArrayList<String> FilteredList = new ArrayList<String>();
        
        FilteredList = new ArrayList<>(curps) ;
        Iterator<String> itr = FilteredList.iterator(); 
        
        switch(genero){
            case "HOMBRE":{
                while(itr.hasNext()){
                    String element = itr.next();
                    if(element.charAt(10) != 'H'){
                        itr.remove();
                    }//if
                }//while
                break;
            }
            case "MUJER":{
                while(itr.hasNext()){
                    String element = itr.next();
                    if(element.charAt(10) != 'M'){
                        itr.remove();
                    }//if
                }//while
                break;
            }
            default:
                System.out.println("ERROR - Valor no identificado");
                return null;
        }//switch
        System.out.println("------- FILTERED " + genero + " -------");
        return FilteredList;
    }

    private List<String> filterEntidad(String entidad) {
        ArrayList<String> FilteredList = new ArrayList<String>();
        
        FilteredList = new ArrayList<>(curps) ;
        Iterator<String> itr = FilteredList.iterator(); 
        
        while(itr.hasNext()){
            String element = itr.next();
            if(!element.substring(11,13).equals(entidad)){
                itr.remove();
            }//if
        }//while

        System.out.println("------- FILTERED " + entidad + " -------");
        return FilteredList;
    }

    private void handleQueryRequest(HttpExchange exchange) throws IOException {
        String query = new String (exchange.getRequestBody().readAllBytes());
        String response = new String();

        // Preguntas que se pueden hacer al servidor
        if (query.equals("CURPS")) {
            int storSize = curps.size();
            response = String.valueOf(storSize);
        } else if (query.equals("HOMBRE")) {
            List<String> listHombre = filterGenero("HOMBRE");
            response = String.valueOf(listHombre.size());
        } else if (query.equals("MUJER")) {
            List<String> listMujer = filterGenero("MUJER");
            response = String.valueOf(listMujer.size());
        } else if (query.equals("MEMORIA")) {
            byte[] stringBytes = curps.get(0).getBytes("UTF-8");
            response = String.valueOf(stringBytes.length * curps.size());
        } else {
            String entidad = query;
            List<String> filteredList = filterEntidad(entidad);
            response = String.valueOf(filteredList.size());
        } 
        sendResponse(response.getBytes(), exchange);
    }

    private void sendResponse(byte[] responseBytes, HttpExchange exchange) throws IOException {
        exchange.sendResponseHeaders(200, responseBytes.length);
        OutputStream outputStream = exchange.getResponseBody();
        outputStream.write(responseBytes);
        outputStream.flush();
        outputStream.close();
        exchange.close();
    }

}
