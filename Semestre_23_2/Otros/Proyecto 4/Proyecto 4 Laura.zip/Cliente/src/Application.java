// Laura Daniela Tellez Castilla --> 2020630527
// Grupo - 4CM11

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Application {
    private static final String MAIN_QUERY_SERVER = "http://localhost:8080/task";
    private static final String Entidad[] = { "AS", "BC", "BS", "CC", "CS", "CH", "CL", "CM", "DF", "DG", "GT", "GR", "HG", "JC", "MC",
                "MN", "MS", "NT", "NL", "OC", "PL", "QT", "QR", "SP", "SL", "SR", "TC", "TL", "TS", "VZ", "YN", "ZS" };
    private static final String NombreEntidad[] = { "Aguascalientes", "Baja California", "Baja California Sur", "Campeche", "Coahuila",
                "Colima", "Chiapas", "Chihuahua", "Ciudad de México", "Durango", "Guanajuato", "Guerrero", "Hidalgo", "Jalisco", "México",
                "Michoacán", "Morelos", "Nayarit", "Nuevo León", "Oaxaca", "Puebla", "Querétaro", "Quintana Roo", "San Luis Potosí",
                "Sinaloa", "Sonora", "Tabasco", "Tamaulipas", "Tlaxcala", "Veracruz", "Yucatán", "Zacatecas" };
    
    public static void mostrarMenu() {
        System.out.println("===============================================");
        System.out.println("\tCONSULTOR DE CURPS");
        System.out.println("===============================================");
        System.out.println("Ingresa una opción para consultar:");
        System.out.println("0 - Memoria usada por la BD");
        System.out.println("1 - Cantidad de CURPS por segundo");
        System.out.println("2 - Cantidad de CURPS en la BD");
        System.out.println("3 - Cantidad de CURPS en cada servidor");
        System.out.println("4 - Cantidad de CURPS de hombres");
        System.out.println("5 - Cantidad de CURPS de mujeres");
        System.out.println("6 - Cantidad de CURPS por estado");
        System.out.println("7 - Salir");
    }

    public static int obtenerOpcion() {
        int opcion = -1;
        try {
            Scanner sc = new Scanner(System.in);
            opcion = sc.nextInt();
            if (opcion < 0 || opcion > 7) {
                System.out.println("Esa opcion no existe!!");
                opcion = -1;
            }
        } catch (Exception e) {
            //Opcion que no se puee convertir
            System.out.println("Esa opcion no existe!!");
            opcion = -1;
        }
        return opcion;
    }

    public static String obtenerEntidad() {
        String entidad = "";
        try {
            Scanner sc = new Scanner(System.in);
            entidad = sc.next();
            if (!Arrays.asList(Entidad).contains(entidad)) {
                System.out.println("Esa entidad no existe!!");
                entidad = "";
            }
        } catch (Exception e) {
            //Opcion que no se puee convertir
            System.out.println("Esa entidad no existe!!");
            entidad = "";
        }
        return entidad;
    }
    public static void main(String[] args) {
        Aggregator aggregator = new Aggregator();

        while (true) {   

            mostrarMenu();

            // Entrada el usuario
            System.out.print("\nOpción --> ");

            int opcion = obtenerOpcion();
            // Error
            if (opcion == -1)
                continue;

            String query = "";
            List<String> result;

            if (opcion == 6) {
                System.out.println("\nEscribe el nombre de una entidad: ");
                for (int i = 0; i < Entidad.length; i++) {
                    System.out.println(Entidad[i] + " - " + NombreEntidad[i]);
                }
                System.out.print("\nEntidad --> ");
                String entidad = obtenerEntidad();
                // Error
                if (entidad.equals(""))
                    continue;
                query = entidad;
            } else if (opcion == 0) {
                query = "MEMORIA";
            } else if (opcion == 1) {
                query = "GENERADOS";
            } else if (opcion == 2) {
                query = "TOTAL";
            } else if (opcion == 3) {
                query = "TOTALSERVIDORES";
            } else if (opcion == 4) {
                query = "HOMBRE";
            } else if (opcion == 5) {
                query = "MUJER";
            } else if (opcion == 7) {
                System.out.println("HASTA LUEGO!!! :D");
                System.exit(0);
            }

            // Query
            result = aggregator.sendTasksToWorkers(Arrays.asList(MAIN_QUERY_SERVER), Arrays.asList(query));

            System.out.println("===============================================");
            System.out.println("\t Respuesta del servidor");
            System.out.println("===============================================\n");
            // Mostramos el resultado de manera distinta segun la opcion elegida
            if (opcion == 6) {
                System.out.println("Cantidad de curps de " + NombreEntidad[Arrays.asList(Entidad).indexOf(query)] + " -> " + result.get(0));
            } else if (opcion == 0) {
                String bytes[] = result.get(0).split(" ");
                for ( int i = 0; i < bytes.length ; i++ ) {
                    String message;
                    // Mensaje o total
                    if ( i == 3)
                        message = "Memoria total de la BD -> ";
                    else
                        message = "Memoria usada en el servidor " + (i+1) + " -> ";
                    
                    // Conversiones
                    if (Long.parseLong(bytes[i]) >= 1000000000) {
                        System.out.println(message + (Float.parseFloat(bytes[i])/1000000000.0) + " GB");
                    } else if (Long.parseLong(bytes[i]) >= 1000000) {
                        System.out.println(message + (Float.parseFloat(bytes[i])/1000000.0) + " MB");
                    } else if (Long.parseLong(bytes[i]) >= 1000) {
                        System.out.println(message + (Float.parseFloat(bytes[i])/1000.0) + " KB");
                    } else {
                        System.out.println(message + bytes[i] + " Bytes");
                    }
                }
            } else if (opcion == 1) {
                System.out.println("Cantidad de CURPS por segundo -> " + result.get(0));
            } else if (opcion == 2) {
                System.out.println("CURPS totales en la BD -> " + result.get(0));
            } else if (opcion == 3) {
                String[] serverSplit = result.get(0).split(" ");
                System.out.println("CURPS almacenados en el servidor 1 -> " + serverSplit[0]);
                System.out.println("CURPS almacenados en el servidor 2 -> " + serverSplit[1]);
                System.out.println("CURPS almacenados en el servidor 3 -> " + serverSplit[2]);
            } else if (opcion == 4) {
                System.out.println("Total de curps de hombres -> " + result.get(0));
            } else if (opcion == 5) {
                System.out.println("Total de curps de mujeres -> " + result.get(0));
            } 
            System.out.println("\n");
        }

    }
}
